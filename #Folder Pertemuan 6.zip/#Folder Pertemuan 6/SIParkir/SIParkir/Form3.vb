﻿Public Class Form3
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim form4 As New Form4()
        form4.Show()
        Me.Close()
    End Sub
End Class